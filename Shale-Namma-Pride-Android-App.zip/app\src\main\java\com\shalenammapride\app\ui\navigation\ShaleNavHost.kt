package com.shalenammapride.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalDining
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shalenammapride.app.ui.auth.LoginScreen
import com.shalenammapride.app.ui.auth.ProfileSetupScreen
import com.shalenammapride.app.ui.auth.SignupScreen
import com.shalenammapride.app.ui.auth.SplashScreen
import com.shalenammapride.app.ui.features.AddDailyMealScreen
import com.shalenammapride.app.ui.features.AddFacilityScreen
import com.shalenammapride.app.ui.features.AddStudentStarScreen
import com.shalenammapride.app.ui.features.AdminFeedbackScreen
import com.shalenammapride.app.ui.features.DailyMealScreen
import com.shalenammapride.app.ui.features.FacilityTourScreen
import com.shalenammapride.app.ui.features.FeedbackScreen
import com.shalenammapride.app.ui.features.GenAiHelperScreen
import com.shalenammapride.app.ui.features.HomeScreen
import com.shalenammapride.app.ui.features.SettingsScreen
import com.shalenammapride.app.ui.features.StudentStarsScreen
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.AppViewModel
import com.shalenammapride.app.viewmodel.SchoolViewModel

private object Routes {
    const val Splash = "splash"
    const val Login = "login"
    const val Signup = "signup"
    const val Profile = "profile"
    const val Home = "home"
    const val Meal = "meal"
    const val AddMeal = "addMeal"
    const val Facilities = "facilities"
    const val AddFacility = "addFacility"
    const val Stars = "stars"
    const val AddStar = "addStar"
    const val Feedback = "feedback"
    const val AdminFeedback = "adminFeedback"
    const val Settings = "settings"
    const val GenAi = "genAi"
}

@Composable
fun ShaleNavHost(appViewModel: AppViewModel) {
    val nav = rememberNavController()
    val appState by appViewModel.state
    val schoolViewModel: SchoolViewModel = viewModel()
    val schoolState by schoolViewModel.state
    val profile = appState.profile

    LaunchedEffect(profile?.uid) {
        if (profile != null) schoolViewModel.loadHome()
    }

    LaunchedEffect(profile?.uid, appState.loading) {
        if (!appState.loading && profile != null) {
            nav.navigate(Routes.Home) {
                popUpTo(Routes.Login) { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    val start = when {
        appState.loading -> Routes.Splash
        profile == null -> Routes.Login
        else -> Routes.Home
    }

    Scaffold(bottomBar = {
        val backStack by nav.currentBackStackEntryAsState()
        val route = backStack?.destination?.route
        if (route in listOf(Routes.Home, Routes.Meal, Routes.Stars, Routes.Feedback, Routes.Settings)) {
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = route == item.route,
                        onClick = {
                            nav.navigate(item.route) {
                                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = null) },
                        label = { Text(item.label()) }
                    )
                }
            }
        }
    }) { padding ->
        NavHost(navController = nav, startDestination = start, modifier = Modifier.padding(padding)) {
            composable(Routes.Splash) { SplashScreen { nav.navigate(if (profile == null) Routes.Login else Routes.Home) } }
            composable(Routes.Login) {
                LoginScreen(
                    state = appState,
                    onLogin = { email, password -> appViewModel.login(email, password) },
                    onSignup = { nav.navigate(Routes.Signup) }
                )
            }
            composable(Routes.Signup) {
                SignupScreen(
                    state = appState,
                    onSignup = { email, password -> appViewModel.signup(email, password) { nav.navigate(Routes.Profile) } },
                    onLogin = { nav.navigate(Routes.Login) }
                )
            }
            composable(Routes.Profile) {
                ProfileSetupScreen(appState, email = "", onSave = { name, email, role, school, lang ->
                    appViewModel.saveProfile(name, email, role, school, lang)
                    nav.navigate(Routes.Home)
                })
            }
            composable(Routes.Home) {
                HomeScreen(
                    profile = profile,
                    language = appState.language,
                    onLanguage = appViewModel::setLanguage,
                    onMeal = { nav.navigate(Routes.Meal) },
                    onFacilities = { nav.navigate(Routes.Facilities) },
                    onStars = { nav.navigate(Routes.Stars) },
                    onFeedback = { nav.navigate(Routes.Feedback) },
                    onAdminFeedback = { nav.navigate(Routes.AdminFeedback) },
                    onGenAi = { nav.navigate(Routes.GenAi) }
                )
            }
            composable(Routes.Meal) {
                DailyMealScreen(schoolState, profile?.canAddUpdates == true, appState.language) { nav.navigate(Routes.AddMeal) }
            }
            composable(Routes.AddMeal) {
                AddDailyMealScreen(schoolState, profile?.uid.orEmpty()) { meal, image ->
                    schoolViewModel.addDailyMeal(meal, image)
                    nav.popBackStack()
                }
            }
            composable(Routes.Facilities) {
                FacilityTourScreen(schoolState, profile?.canAddUpdates == true, appState.language) { nav.navigate(Routes.AddFacility) }
            }
            composable(Routes.AddFacility) {
                AddFacilityScreen(schoolState) { facility, image ->
                    schoolViewModel.addFacility(facility, image)
                    nav.popBackStack()
                }
            }
            composable(Routes.Stars) {
                StudentStarsScreen(schoolState, profile?.canAddUpdates == true, appState.language) { nav.navigate(Routes.AddStar) }
            }
            composable(Routes.AddStar) {
                AddStudentStarScreen(schoolState) { star, image ->
                    schoolViewModel.addStudentStar(star, image)
                    nav.popBackStack()
                }
            }
            composable(Routes.Feedback) {
                FeedbackScreen(schoolState, profile) { feedback ->
                    schoolViewModel.submitFeedback(feedback)
                    if (profile?.canAddUpdates == true) nav.navigate(Routes.AdminFeedback)
                }
            }
            composable(Routes.AdminFeedback) {
                LaunchedEffect(Unit) { schoolViewModel.loadFeedback() }
                AdminFeedbackScreen(schoolState)
            }
            composable(Routes.Settings) {
                SettingsScreen(appState, appViewModel::setLanguage) {
                    appViewModel.logout()
                    nav.navigate(Routes.Login) {
                        popUpTo(nav.graph.findStartDestination().id) { inclusive = true }
                    }
                }
            }
            composable(Routes.GenAi) {
                GenAiHelperScreen(schoolState, schoolViewModel::generateAnnouncement)
            }
        }
    }
}

private data class BottomItem(
    val route: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val label: @Composable () -> String
)

private val bottomItems = listOf(
    BottomItem(Routes.Home, Icons.Default.Home) { text("Home", "ಮುಖಪುಟ") },
    BottomItem(Routes.Meal, Icons.Default.LocalDining) { text("Meal", "ಊಟ") },
    BottomItem(Routes.Stars, Icons.Default.Star) { text("Stars", "ತಾರೆಗಳು") },
    BottomItem(Routes.Feedback, Icons.Default.Feedback) { text("Feedback", "ಪ್ರತಿಕ್ರಿಯೆ") },
    BottomItem(Routes.Settings, Icons.Default.Settings) { text("Settings", "ಸೆಟ್ಟಿಂಗ್ಸ್") }
)
