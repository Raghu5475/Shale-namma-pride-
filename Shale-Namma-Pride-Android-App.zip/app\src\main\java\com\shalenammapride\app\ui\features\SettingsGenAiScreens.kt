package com.shalenammapride.app.ui.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.ui.components.EnumDropdown
import com.shalenammapride.app.ui.components.FormColumn
import com.shalenammapride.app.ui.components.LoadingOrError
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.AppState
import com.shalenammapride.app.viewmodel.SchoolState

@Composable
fun SettingsScreen(state: AppState, onLanguage: (AppLanguage) -> Unit, onLogout: () -> Unit) {
    val language = remember(state.language) { mutableStateOf(state.language) }
    ScreenScaffold(title = text("Settings", "ಸೆಟ್ಟಿಂಗ್ಸ್")) { _ ->
        FormColumn {
            Text(state.profile?.name.orEmpty())
            Text(state.profile?.schoolName.orEmpty())
            EnumDropdown(text("Language", "ಭಾಷೆ"), AppLanguage.entries.toTypedArray(), language.value) {
                language.value = it
                onLanguage(it)
            }
            OutlinedButton(onClick = onLogout, modifier = Modifier.fillMaxWidth()) {
                Text(text("Logout", "ಲಾಗ್ ಔಟ್"))
            }
        }
    }
}

@Composable
fun GenAiHelperScreen(state: SchoolState, onGenerate: (String) -> Unit) {
    val input = remember { mutableStateOf("") }
    ScreenScaffold(title = text("GenAI Helper", "GenAI ಸಹಾಯಕ")) { _ ->
        FormColumn {
            OutlinedTextField(
                input.value,
                { input.value = it },
                label = { Text(text("Short update text", "ಸಣ್ಣ ಮಾಹಿತಿ")) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Button(onClick = { onGenerate(input.value) }, modifier = Modifier.fillMaxWidth()) {
                Text(text("Generate announcement", "ಪ್ರಕಟಣೆ ರಚಿಸಿ"))
            }
            LoadingOrError(state.loading, state.error)
            if (state.announcement.english.isNotBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("English")
                    Text(state.announcement.english)
                    Text("Kannada")
                    Text(state.announcement.kannada)
                }
            }
        }
    }
}
