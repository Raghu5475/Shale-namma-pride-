package com.shalenammapride.app.ui.features

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.data.model.DailyMeal
import com.shalenammapride.app.data.repository.SchoolRepository
import com.shalenammapride.app.ui.components.EmptyState
import com.shalenammapride.app.ui.components.FormColumn
import com.shalenammapride.app.ui.components.ImagePicker
import com.shalenammapride.app.ui.components.LoadingOrError
import com.shalenammapride.app.ui.components.MealIcon
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.components.UpdateImage
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.SchoolState

@Composable
fun DailyMealScreen(state: SchoolState, canAdd: Boolean, language: AppLanguage, onAdd: () -> Unit) {
    ScreenScaffold(title = text("Daily Meal", "ದೈನಂದಿನ ಊಟ"), actions = {
        if (canAdd) Button(onClick = onAdd) { Text(text("Add", "ಸೇರಿಸಿ")) }
    }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            LoadingOrError(state.loading, state.error)
            val meal = state.todayMeal
            if (meal == null) EmptyState(
                text("No meal update yet", "ಇನ್ನೂ ಊಟದ ಮಾಹಿತಿ ಇಲ್ಲ"),
                text("Today's meal will appear here.", "ಇಂದಿನ ಊಟದ ಮಾಹಿತಿ ಇಲ್ಲಿ ಕಾಣುತ್ತದೆ."),
                MealIcon
            ) else MealCard(meal, language)
        }
    }
}

@Composable
fun MealCard(meal: DailyMeal, language: AppLanguage) {
    Card(colors = CardDefaults.cardColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            UpdateImage(meal.imageUrl)
            Text(if (language == AppLanguage.KANNADA) meal.menuKannada else meal.menuEnglish, fontWeight = FontWeight.Bold)
            Text(if (language == AppLanguage.KANNADA) meal.descriptionKannada else meal.descriptionEnglish)
            Text(meal.date)
        }
    }
}

@Composable
fun AddDailyMealScreen(state: SchoolState, uploadedBy: String, onSave: (DailyMeal, Uri?) -> Unit) {
    var menuEn = remember { mutableStateOf("") }
    var menuKn = remember { mutableStateOf("") }
    var descEn = remember { mutableStateOf("") }
    var descKn = remember { mutableStateOf("") }
    var date = remember { mutableStateOf(SchoolRepository.today()) }
    val image = remember { mutableStateOf<Uri?>(null) }
    ScreenScaffold(title = text("Add Daily Meal", "ಊಟದ ಮಾಹಿತಿ ಸೇರಿಸಿ")) { padding ->
        FormColumn {
            OutlinedTextField(date.value, { date.value = it }, label = { Text("YYYY-MM-DD") }, modifier = Modifier.fillMaxWidth())
            ImagePicker(image)
            OutlinedTextField(menuEn.value, { menuEn.value = it }, label = { Text("Menu English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(menuKn.value, { menuKn.value = it }, label = { Text("Menu Kannada") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descEn.value, { descEn.value = it }, label = { Text("Description English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descKn.value, { descKn.value = it }, label = { Text("Description Kannada") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                onSave(DailyMeal(date = date.value, menuEnglish = menuEn.value, menuKannada = menuKn.value, descriptionEnglish = descEn.value, descriptionKannada = descKn.value, uploadedBy = uploadedBy), image.value)
            }, modifier = Modifier.fillMaxWidth()) { Text(text("Save meal", "ಊಟ ಉಳಿಸಿ")) }
            LoadingOrError(state.loading, state.error)
        }
    }
}
