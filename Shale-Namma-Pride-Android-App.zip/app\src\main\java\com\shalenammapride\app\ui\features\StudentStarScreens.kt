package com.shalenammapride.app.ui.features

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.data.model.StudentStar
import com.shalenammapride.app.ui.components.EmptyState
import com.shalenammapride.app.ui.components.FormColumn
import com.shalenammapride.app.ui.components.ImagePicker
import com.shalenammapride.app.ui.components.LoadingOrError
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.components.StarsIcon
import com.shalenammapride.app.ui.components.UpdateImage
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.SchoolState

@Composable
fun StudentStarsScreen(state: SchoolState, canAdd: Boolean, language: AppLanguage, onAdd: () -> Unit) {
    ScreenScaffold(title = text("Student Stars", "ವಿದ್ಯಾರ್ಥಿ ತಾರೆಗಳು"), actions = {
        if (canAdd) Button(onClick = onAdd) { Text(text("Add", "ಸೇರಿಸಿ")) }
    }) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { LoadingOrError(state.loading, state.error) }
            if (state.studentStars.isEmpty()) {
                item { EmptyState(text("No stars yet", "ಇನ್ನೂ ಸಾಧನೆಗಳಿಲ್ಲ"), text("Student achievements will shine here.", "ವಿದ್ಯಾರ್ಥಿಗಳ ಸಾಧನೆಗಳು ಇಲ್ಲಿ ಕಾಣುತ್ತವೆ."), StarsIcon) }
            } else {
                items(state.studentStars) { StarCard(it, language) }
            }
        }
    }
}

@Composable
private fun StarCard(star: StudentStar, language: AppLanguage) {
    Card(colors = CardDefaults.cardColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            UpdateImage(star.imageUrl)
            Text(star.studentName, fontWeight = FontWeight.Bold)
            Text(if (language == AppLanguage.KANNADA) star.titleKannada else star.titleEnglish, fontWeight = FontWeight.Bold)
            Text(if (language == AppLanguage.KANNADA) star.descriptionKannada else star.descriptionEnglish)
        }
    }
}

@Composable
fun AddStudentStarScreen(state: SchoolState, onSave: (StudentStar, Uri?) -> Unit) {
    val studentName = remember { mutableStateOf("") }
    val titleEn = remember { mutableStateOf("") }
    val titleKn = remember { mutableStateOf("") }
    val descEn = remember { mutableStateOf("") }
    val descKn = remember { mutableStateOf("") }
    val image = remember { mutableStateOf<Uri?>(null) }
    ScreenScaffold(title = text("Add Student Star", "ವಿದ್ಯಾರ್ಥಿ ತಾರೆ ಸೇರಿಸಿ")) {
        FormColumn {
            ImagePicker(image)
            OutlinedTextField(studentName.value, { studentName.value = it }, label = { Text(text("Student name", "ವಿದ್ಯಾರ್ಥಿ ಹೆಸರು")) }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(titleEn.value, { titleEn.value = it }, label = { Text("Achievement English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(titleKn.value, { titleKn.value = it }, label = { Text("Achievement Kannada") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descEn.value, { descEn.value = it }, label = { Text("Description English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descKn.value, { descKn.value = it }, label = { Text("Description Kannada") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                onSave(StudentStar(studentName = studentName.value, titleEnglish = titleEn.value, titleKannada = titleKn.value, descriptionEnglish = descEn.value, descriptionKannada = descKn.value), image.value)
            }, modifier = Modifier.fillMaxWidth()) { Text(text("Save star", "ತಾರೆ ಉಳಿಸಿ")) }
            LoadingOrError(state.loading, state.error)
        }
    }
}
