package com.shalenammapride.app.ui.features

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.data.model.Facility
import com.shalenammapride.app.data.model.FacilityCategory
import com.shalenammapride.app.ui.components.EmptyState
import com.shalenammapride.app.ui.components.EnumDropdown
import com.shalenammapride.app.ui.components.FacilityIcon
import com.shalenammapride.app.ui.components.FormColumn
import com.shalenammapride.app.ui.components.ImagePicker
import com.shalenammapride.app.ui.components.LoadingOrError
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.components.UpdateImage
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.SchoolState

@Composable
fun FacilityTourScreen(state: SchoolState, canAdd: Boolean, language: AppLanguage, onAdd: () -> Unit) {
    ScreenScaffold(title = text("Facility Tour", "ಸೌಲಭ್ಯಗಳ ಪರಿಚಯ"), actions = {
        if (canAdd) Button(onClick = onAdd) { Text(text("Add", "ಸೇರಿಸಿ")) }
    }) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { LoadingOrError(state.loading, state.error) }
            if (state.facilities.isEmpty()) {
                item { EmptyState(text("No facility images", "ಸೌಲಭ್ಯ ಚಿತ್ರಗಳಿಲ್ಲ"), text("Admin uploads will appear here.", "ಅಪ್ಲೋಡ್ ಮಾಡಿದ ಚಿತ್ರಗಳು ಇಲ್ಲಿ ಕಾಣುತ್ತವೆ."), FacilityIcon) }
            } else {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(state.facilities) { FacilityCard(it, language) }
                    }
                }
            }
        }
    }
}

@Composable
private fun FacilityCard(facility: Facility, language: AppLanguage) {
    Card(colors = CardDefaults.cardColors(), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            UpdateImage(facility.imageUrl)
            Text(if (language == AppLanguage.KANNADA) facility.titleKannada else facility.titleEnglish, fontWeight = FontWeight.Bold)
            Text(facility.category.name.replace('_', ' '))
            Text(if (language == AppLanguage.KANNADA) facility.descriptionKannada else facility.descriptionEnglish)
        }
    }
}

@Composable
fun AddFacilityScreen(state: SchoolState, onSave: (Facility, Uri?) -> Unit) {
    val titleEn = remember { mutableStateOf("") }
    val titleKn = remember { mutableStateOf("") }
    val descEn = remember { mutableStateOf("") }
    val descKn = remember { mutableStateOf("") }
    val image = remember { mutableStateOf<Uri?>(null) }
    val category = remember { mutableStateOf(FacilityCategory.CLASSROOMS) }
    ScreenScaffold(title = text("Add Facility", "ಸೌಲಭ್ಯ ಸೇರಿಸಿ")) {
        FormColumn {
            ImagePicker(image)
            EnumDropdown("Category", FacilityCategory.entries.toTypedArray(), category.value) { category.value = it }
            OutlinedTextField(titleEn.value, { titleEn.value = it }, label = { Text("Title English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(titleKn.value, { titleKn.value = it }, label = { Text("Title Kannada") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descEn.value, { descEn.value = it }, label = { Text("Description English") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(descKn.value, { descKn.value = it }, label = { Text("Description Kannada") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                onSave(Facility(titleEnglish = titleEn.value, titleKannada = titleKn.value, descriptionEnglish = descEn.value, descriptionKannada = descKn.value, category = category.value), image.value)
            }, modifier = Modifier.fillMaxWidth()) { Text(text("Save facility", "ಸೌಲಭ್ಯ ಉಳಿಸಿ")) }
            LoadingOrError(state.loading, state.error)
        }
    }
}
