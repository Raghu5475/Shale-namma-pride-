package com.shalenammapride.app.ui.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.data.model.UserProfile
import com.shalenammapride.app.ui.components.DashboardCard
import com.shalenammapride.app.ui.components.FacilityIcon
import com.shalenammapride.app.ui.components.FeedbackIcon
import com.shalenammapride.app.ui.components.GenAiIcon
import com.shalenammapride.app.ui.components.MealIcon
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.components.StarsIcon
import com.shalenammapride.app.ui.theme.text

@Composable
fun HomeScreen(
    profile: UserProfile?,
    language: AppLanguage,
    onLanguage: (AppLanguage) -> Unit,
    onMeal: () -> Unit,
    onFacilities: () -> Unit,
    onStars: () -> Unit,
    onFeedback: () -> Unit,
    onAdminFeedback: () -> Unit,
    onGenAi: () -> Unit
) {
    ScreenScaffold(
        title = text("School Dashboard", "ಶಾಲಾ ಡ್ಯಾಶ್ಬೋರ್ಡ್"),
        actions = {
            FilterChip(selected = language == AppLanguage.KANNADA, onClick = {
                onLanguage(if (language == AppLanguage.ENGLISH) AppLanguage.KANNADA else AppLanguage.ENGLISH)
            }, label = { Text(if (language == AppLanguage.ENGLISH) "ಕನ್ನಡ" else "English") })
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = padding.calculateTopPadding() + 16.dp,
                bottom = padding.calculateBottomPadding() + 86.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                DashboardCard(
                    title = text("Daily Meal Update", "ದೈನಂದಿನ ಊಟದ ಮಾಹಿತಿ"),
                    subtitle = text("See today's mid-day meal", "ಇಂದಿನ ಮಧ್ಯಾಹ್ನದ ಊಟ ನೋಡಿ"),
                    icon = MealIcon,
                    onClick = onMeal
                )
            }
            item {
                DashboardCard(
                    title = text("Facility Tour", "ಸೌಲಭ್ಯಗಳ ಪರಿಚಯ"),
                    subtitle = text("Classrooms, library, labs, and playground", "ತರಗತಿಗಳು, ಗ್ರಂಥಾಲಯ, ಪ್ರಯೋಗಾಲಯಗಳು"),
                    icon = FacilityIcon,
                    onClick = onFacilities
                )
            }
            item {
                DashboardCard(
                    title = text("Student Stars", "ವಿದ್ಯಾರ್ಥಿ ತಾರೆಗಳು"),
                    subtitle = text("Celebrate achievements", "ಸಾಧನೆಗಳನ್ನು ಆಚರಿಸಿ"),
                    icon = StarsIcon,
                    onClick = onStars
                )
            }
            item {
                DashboardCard(
                    title = text("Feedback Box", "ಪ್ರತಿಕ್ರಿಯೆ ಪೆಟ್ಟಿಗೆ"),
                    subtitle = text("Share suggestions with the school", "ಶಾಲೆಯೊಂದಿಗೆ ಸಲಹೆ ಹಂಚಿಕೊಳ್ಳಿ"),
                    icon = FeedbackIcon,
                    onClick = onFeedback
                )
            }
            if (profile?.canAddUpdates == true) {
                item {
                    DashboardCard(
                        title = text("Admin Feedback View", "ನಿರ್ವಾಹಕ ಪ್ರತಿಕ್ರಿಯೆ"),
                        subtitle = text("Review parent and community messages", "ಪೋಷಕರು ಮತ್ತು ಸಮುದಾಯದ ಸಂದೇಶಗಳನ್ನು ನೋಡಿ"),
                        icon = FeedbackIcon,
                        onClick = onAdminFeedback
                    )
                }
                item {
                    DashboardCard(
                        title = text("GenAI Helper", "GenAI ಸಹಾಯಕ"),
                        subtitle = text("Draft English and Kannada announcements", "ಇಂಗ್ಲಿಷ್ ಮತ್ತು ಕನ್ನಡ ಪ್ರಕಟಣೆ ರಚಿಸಿ"),
                        icon = GenAiIcon,
                        onClick = onGenAi
                    )
                }
            }
        }
    }
}
