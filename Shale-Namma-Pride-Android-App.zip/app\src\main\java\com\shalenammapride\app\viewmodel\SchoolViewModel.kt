package com.shalenammapride.app.viewmodel

import android.net.Uri
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenammapride.app.data.model.AnnouncementDraft
import com.shalenammapride.app.data.model.DailyMeal
import com.shalenammapride.app.data.model.Facility
import com.shalenammapride.app.data.model.SchoolFeedback
import com.shalenammapride.app.data.model.StudentStar
import com.shalenammapride.app.data.repository.SchoolRepository
import com.shalenammapride.app.data.service.GenAiService
import kotlinx.coroutines.launch

data class SchoolState(
    val loading: Boolean = false,
    val error: String? = null,
    val todayMeal: DailyMeal? = null,
    val facilities: List<Facility> = emptyList(),
    val studentStars: List<StudentStar> = emptyList(),
    val feedback: List<SchoolFeedback> = emptyList(),
    val announcement: AnnouncementDraft = AnnouncementDraft(),
    val saved: Boolean = false
)

class SchoolViewModel(
    private val repository: SchoolRepository = SchoolRepository(),
    private val genAiService: GenAiService = GenAiService()
) : ViewModel() {
    private val _state = mutableStateOf(SchoolState())
    val state: State<SchoolState> = _state

    fun loadHome() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null, saved = false)
            runCatching {
                SchoolState(
                    todayMeal = repository.todayMeal(),
                    facilities = repository.facilities(),
                    studentStars = repository.studentStars()
                )
            }.onSuccess { _state.value = it }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    fun loadFeedback() {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching { repository.feedback() }
                .onSuccess { _state.value = _state.value.copy(loading = false, feedback = it) }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    fun addDailyMeal(meal: DailyMeal, imageUri: Uri?) = save { repository.addDailyMeal(meal, imageUri) }
    fun addFacility(facility: Facility, imageUri: Uri?) = save { repository.addFacility(facility, imageUri) }
    fun addStudentStar(star: StudentStar, imageUri: Uri?) = save { repository.addStudentStar(star, imageUri) }
    fun submitFeedback(feedback: SchoolFeedback) = save { repository.submitFeedback(feedback) }

    fun generateAnnouncement(input: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null)
            runCatching { genAiService.generateAnnouncement(input) }
                .onSuccess { _state.value = _state.value.copy(loading = false, announcement = it) }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    private fun save(block: suspend () -> Unit) {
        viewModelScope.launch {
            _state.value = _state.value.copy(loading = true, error = null, saved = false)
            runCatching { block() }
                .onSuccess {
                    _state.value = _state.value.copy(loading = false, saved = true)
                    loadHome()
                }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }
}
