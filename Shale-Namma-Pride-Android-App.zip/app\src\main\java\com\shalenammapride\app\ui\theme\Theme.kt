package com.shalenammapride.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import com.shalenammapride.app.data.model.AppLanguage

val LocalAppLanguage = compositionLocalOf { AppLanguage.ENGLISH }

private val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF2E7D65),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEFE1),
    secondary = Color(0xFFE86F51),
    secondaryContainer = Color(0xFFFFDAD1),
    tertiary = Color(0xFF4766A9),
    background = Color(0xFFFFFBF4),
    surface = Color(0xFFFFFBF4),
    surfaceVariant = Color(0xFFFFE8B8),
    error = Color(0xFFB3261E)
)

@Composable
fun ShaleNammaPrideTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = MaterialTheme.typography,
        content = content
    )
}

@Composable
fun text(en: String, kn: String): String =
    if (LocalAppLanguage.current == AppLanguage.KANNADA) kn else en
