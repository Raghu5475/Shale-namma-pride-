package com.shalenammapride.app.ui.features

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.shalenammapride.app.data.model.FeedbackCategory
import com.shalenammapride.app.data.model.SchoolFeedback
import com.shalenammapride.app.data.model.UserProfile
import com.shalenammapride.app.ui.components.EmptyState
import com.shalenammapride.app.ui.components.EnumDropdown
import com.shalenammapride.app.ui.components.FeedbackIcon
import com.shalenammapride.app.ui.components.FormColumn
import com.shalenammapride.app.ui.components.LoadingOrError
import com.shalenammapride.app.ui.components.ScreenScaffold
import com.shalenammapride.app.ui.theme.text
import com.shalenammapride.app.viewmodel.SchoolState

@Composable
fun FeedbackScreen(state: SchoolState, profile: UserProfile?, onSave: (SchoolFeedback) -> Unit) {
    val message = remember { mutableStateOf("") }
    val category = remember { mutableStateOf(FeedbackCategory.MEAL) }
    val anonymous = remember { mutableStateOf(false) }
    ScreenScaffold(title = text("Feedback Box", "ಪ್ರತಿಕ್ರಿಯೆ ಪೆಟ್ಟಿಗೆ")) { _ ->
        FormColumn {
            OutlinedTextField(
                value = message.value,
                onValueChange = { message.value = it },
                label = { Text(text("Feedback", "ಪ್ರತಿಕ್ರಿಯೆ")) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 4
            )
            EnumDropdown(text("Category", "ವರ್ಗ"), FeedbackCategory.entries.toTypedArray(), category.value) { category.value = it }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = anonymous.value, onCheckedChange = { anonymous.value = it })
                Text(text("Submit anonymously", "ಅನಾಮಧೇಯವಾಗಿ ಸಲ್ಲಿಸಿ"))
            }
            Button(onClick = {
                val publicName = if (anonymous.value) null else profile?.name
                onSave(SchoolFeedback(message = message.value, category = category.value, anonymous = anonymous.value, userId = profile?.uid.orEmpty(), userName = publicName))
            }, modifier = Modifier.fillMaxWidth()) { Text(text("Submit feedback", "ಪ್ರತಿಕ್ರಿಯೆ ಸಲ್ಲಿಸಿ")) }
            LoadingOrError(state.loading, state.error)
        }
    }
}

@Composable
fun AdminFeedbackScreen(state: SchoolState) {
    ScreenScaffold(title = text("Admin Feedback", "ನಿರ್ವಾಹಕ ಪ್ರತಿಕ್ರಿಯೆ")) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = padding.calculateTopPadding() + 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { LoadingOrError(state.loading, state.error) }
            if (state.feedback.isEmpty()) {
                item { EmptyState(text("No feedback yet", "ಇನ್ನೂ ಪ್ರತಿಕ್ರಿಯೆಗಳಿಲ್ಲ"), text("Parent feedback will appear here.", "ಪೋಷಕರ ಪ್ರತಿಕ್ರಿಯೆ ಇಲ್ಲಿ ಕಾಣುತ್ತದೆ."), FeedbackIcon) }
            } else {
                items(state.feedback) { item ->
                    Card(colors = CardDefaults.cardColors(), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(item.category.name, fontWeight = FontWeight.Bold)
                            Text(item.message)
                            Text(if (item.anonymous) text("Anonymous", "ಅನಾಮಧೇಯ") else item.userName.orEmpty())
                        }
                    }
                }
            }
        }
    }
}
