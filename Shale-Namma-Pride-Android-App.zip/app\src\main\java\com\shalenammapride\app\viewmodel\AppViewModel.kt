package com.shalenammapride.app.viewmodel

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shalenammapride.app.data.model.AppLanguage
import com.shalenammapride.app.data.model.UserProfile
import com.shalenammapride.app.data.model.UserRole
import com.shalenammapride.app.data.repository.AuthRepository
import kotlinx.coroutines.launch

data class AppState(
    val loading: Boolean = true,
    val profile: UserProfile? = null,
    val error: String? = null,
    val language: AppLanguage = AppLanguage.ENGLISH
)

class AppViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {
    private val _state = mutableStateOf(AppState())
    val state: State<AppState> = _state

    init {
        refreshProfile()
    }

    fun refreshProfile() {
        viewModelScope.launch {
            runCatching { authRepository.getProfile() }
                .onSuccess { profile ->
                    _state.value = AppState(
                        loading = false,
                        profile = profile,
                        language = profile?.preferredLanguage ?: AppLanguage.ENGLISH
                    )
                }
                .onFailure { _state.value = AppState(loading = false, error = it.message) }
        }
    }

    fun login(email: String, password: String) {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            runCatching { authRepository.login(email, password) }
                .onSuccess { profile ->
                    _state.value = AppState(
                        loading = false,
                        profile = profile.takeIf { it.uid.isNotBlank() },
                        language = profile.preferredLanguage
                    )
                }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    fun signup(email: String, password: String, onCreated: () -> Unit) {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            runCatching { authRepository.signup(email, password) }
                .onSuccess {
                    _state.value = _state.value.copy(loading = false)
                    onCreated()
                }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    fun saveProfile(name: String, email: String, role: UserRole, school: String, language: AppLanguage) {
        _state.value = _state.value.copy(loading = true, error = null)
        viewModelScope.launch {
            runCatching { authRepository.ensureProfile(name, email, role, school, language) }
                .onSuccess { _state.value = AppState(false, it, language = it.preferredLanguage) }
                .onFailure { _state.value = _state.value.copy(loading = false, error = it.message) }
        }
    }

    fun setLanguage(language: AppLanguage) {
        val profile = _state.value.profile
        _state.value = _state.value.copy(language = language, profile = profile?.copy(preferredLanguage = language))
        if (profile != null) {
            viewModelScope.launch { authRepository.saveProfile(profile.copy(preferredLanguage = language)) }
        }
    }

    fun logout() {
        authRepository.logout()
        _state.value = AppState(loading = false)
    }
}
